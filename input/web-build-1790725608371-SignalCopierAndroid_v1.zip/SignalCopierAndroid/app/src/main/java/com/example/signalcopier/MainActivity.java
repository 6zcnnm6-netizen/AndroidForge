package com.example.signalcopier;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,12,22));
        getWindow().setNavigationBarColor(Color.rgb(4,7,13));
        setContentView(new DashboardView(this));
    }

    static class DashboardView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        float d;
        int W, H;
        int bg=Color.rgb(7,12,22), panel=Color.rgb(22,30,49), panel2=Color.rgb(20,28,47);
        int cyan=Color.rgb(0,220,255), green=Color.rgb(0,239,128), muted=Color.rgb(120,132,160);
        RectF r = new RectF();

        DashboardView(Context c) {
            super(c);
            d=getResources().getDisplayMetrics().density;
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2*d);
        }
        float dp(float x){return x*d;}
        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){
            p.setStyle(Paint.Style.FILL); p.setTextSize(dp(size)); p.setColor(color); p.setTextAlign(a);
            c.drawText(s,dp(x),dp(y),p);
        }
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){
            p.setStyle(Paint.Style.FILL); p.setColor(color); r.set(dp(l),dp(t),dp(rr),dp(bb)); c.drawRoundRect(r,dp(rad),dp(rad),p);
        }
        void outline(Canvas c,float l,float t,float rr,float bb,float rad,int color,float sw){
            stroke.setColor(color); stroke.setStrokeWidth(dp(sw)); r.set(dp(l),dp(t),dp(rr),dp(bb)); c.drawRoundRect(r,dp(rad),dp(rad),stroke);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); W=getWidth(); H=getHeight();
            c.drawColor(bg);
            float width=W/d;
            // Header
            txt(c,"⚡",width-42,40,20,green,Paint.Align.CENTER);
            txt(c,"S I G N A L   C O P I E R",width-32,42,14,cyan,Paint.Align.RIGHT);
            round(c,31,22,279,70,32,Color.TRANSPARENT);
            outline(c,31,22,279,70,32,green,2.5f);
            txt(c,"COPIE ACTIVE ⚡",155,53,18,green,Paint.Align.CENTER);

            // broker card
            round(c,31,87,width-31,196,29,Color.rgb(45,12,28));
            outline(c,31,87,width-31,196,29,Color.rgb(130,10,48),1.5f);
            txt(c,"→ Connecter",52,122,17,cyan,Paint.Align.LEFT);
            txt(c,"Aucun broker connecté",width/2+48,122,17,Color.rgb(255,48,86),Paint.Align.CENTER);
            txt(c,"⌁",width-62,126,28,Color.rgb(255,48,86),Paint.Align.CENTER);

            // Main settings panel
            float top=280;
            round(c,31,top,width-31,713,29,panel);
            outline(c,31,top,width-31,713,29,Color.rgb(0,150,180),1.4f);
            txt(c,"لتفعيل النسخ",width-56,319,20,Color.WHITE,Paint.Align.RIGHT);
            row(c,368,"دفع الاشتراك");
            row(c,476,"ربط تيليجرام");
            row(c,584,"ربط الوسيط");

            // Stats cards
            stat(c,723,"الصفقات المنسوخة","0","▣",cyan);
            stat(c,829,"إجمالي الربح","USD 0.00+","⌁",green);
            stat(c,935,"معدل الفوز","0%","♛",Color.YELLOW);
            stat(c,1041,"المراكز المفتوحة","0","▥",cyan);

            // Bottom navigation
            float navTop=1130;
            round(c,0,navTop,width,1240,0,Color.rgb(10,21,37));
            nav(c,62,1180,"♙","الحساب",false);
            nav(c,176,1180,"➤","تيليجرام",false);
            nav(c,290,1180,"♧","Traders",false);
            nav(c,404,1180,"□","القنوات",false);
            nav(c,518,1180,"ϟ","الإشارات",false);
            round(c,width-118,1142,width-8,1232,24,Color.rgb(0,74,92));
            nav(c,width-63,1180,"▦","الرئيسية",true);
        }
        void row(Canvas c,float y,String title){
            txt(c,"متابعة",100,y+5,17,cyan,Paint.Align.CENTER);
            txt(c,title,getWidth()/d-77,y+5,18,Color.WHITE,Paint.Align.RIGHT);
            outline(c,getWidth()/d-80,y-23,getWidth()/d-48,y+9,20,Color.rgb(58,76,112),2);
        }
        void stat(Canvas c,float y,String title,String value,String icon,int col){
            float width=getWidth()/d;
            round(c,31,y,width-31,y+91,25,panel2);
            txt(c,title,width-102,y+52,17,muted,Paint.Align.RIGHT);
            txt(c,value,210,y+56,22,col,Paint.Align.CENTER);
            round(c,width-92,y+15,width-31,y+76,20,Color.rgb(8,55,75));
            txt(c,icon,width-61,y+54,25,col,Paint.Align.CENTER);
        }
        void nav(Canvas c,float x,float y,String icon,String title,boolean active){
            int col=active?cyan:Color.rgb(70,89,124);
            txt(c,icon,x,y-4,27,col,Paint.Align.CENTER);
            txt(c,title,x,y+31,13,active?cyan:Color.rgb(70,82,106),Paint.Align.CENTER);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX()/d, y=e.getY()/d;
            if(y>87 && y<196){ toast("صفحة ربط الوسيط - سيتم ربط MT5 في المرحلة التالية"); }
            else if(y>330 && y<430){ toast("دفع الاشتراك"); }
            else if(y>=430 && y<535){ toast("ربط Telegram - سيتم تفعيله في المرحلة التالية"); }
            else if(y>=535 && y<650){ toast("ربط الوسيط MT5 - سيتم تفعيله في المرحلة التالية"); }
            else if(y>1120){ toast("هذه النسخة هي الواجهة الأولى"); }
            return true;
        }
        void toast(String s){ Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show(); }
    }
}
